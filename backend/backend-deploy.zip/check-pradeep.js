require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

mongoose.connect(process.env.MONGO_URI || process.env.MONGODB_URI).then(async () => {
  const user = await User.findOne({ email: 'production@megakemglobal.com' });
  console.log("USER:", JSON.stringify(user, null, 2));
  process.exit(0);
}).catch(err => {
  console.error(err);
  process.exit(1);
});
