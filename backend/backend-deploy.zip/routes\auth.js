const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const { logAction } = require('../middleware/audit');

// Generate JWT Token
const generateToken = (id, expiresIn = null) => {
  const jwtSecret = process.env.JWT_SECRET || 'default-secret-change-in-production';
  return jwt.sign({ id }, jwtSecret, {
    expiresIn: expiresIn || process.env.JWT_EXPIRE || '7d'
  });
};

// Generate Refresh Token
const generateRefreshToken = (id) => {
  const jwtSecret = process.env.JWT_SECRET || 'default-secret-change-in-production';
  return jwt.sign({ id, type: 'refresh' }, jwtSecret, {
    expiresIn: process.env.JWT_REFRESH_EXPIRE || '30d'
  });
};

// @route   POST /api/auth/register
// @desc    Register a new user
// @access  Public
router.post('/register', [
  body('username')
    .trim()
    .isLength({ min: 3, max: 30 })
    .withMessage('Username must be between 3 and 30 characters')
    .matches(/^[a-zA-Z0-9_-]+$/)
    .withMessage('Username can only contain letters, numbers, underscores and hyphens'),
  body('email')
    .trim()
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number')
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { username, email, password } = req.body;

    // Check if user exists
    const userExists = await User.findOne({ $or: [{ email }, { username }] });
    if (userExists) {
      return res.status(400).json({
        success: false,
        message: 'User already exists'
      });
    }

    // Create user
    const user = await User.create({
      username,
      email,
      password
    });

    const token = generateToken(user._id);
    const refreshToken = generateRefreshToken(user._id);

    // Audit Log
    req.user = user;
    await logAction(req, 'REGISTER_USER', 'AUTH', { 
      userId: user._id, 
      email: user.email 
    });

    res.status(201).json({
      success: true,
      data: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        token,
        refreshToken
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   POST /api/auth/login
// @desc    Login user
// @access  Public
router.post('/login', [
  body('email')
    .trim()
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .notEmpty()
    .withMessage('Password is required')
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { email, password } = req.body;

    console.log('🔑 User login attempt:', { email, hasPassword: !!password });

    // Check for user
    const user = await User.findOne({ email }).select('+password');
    console.log('👤 User found:', user ? `Yes (${user.username})` : 'No');
    
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check if user is active
    if (!user.isActive) {
      console.log('❌ User account is deactivated');
      return res.status(401).json({
        success: false,
        message: 'Account is deactivated. Please contact admin.'
      });
    }

    // Check if password matches
    console.log('🔐 Checking password...');
    const isMatch = await user.comparePassword(password);
    console.log('🔐 Password match:', isMatch);
    
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Update last login
    user.lastLogin = Date.now();
    await user.save();

    console.log('✅ User login successful');

    const token = generateToken(user._id);
    const refreshToken = generateRefreshToken(user._id);

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    });

    res.json({
      success: true,
      data: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        points: user.points,
        tier: user.tier,
        totalScans: user.totalScans,
        achievements: user.achievements,
        token, // Keep for backward compatibility during transition
        refreshToken
      }
    });
  } catch (error) {
    console.error('❌ Login error:', error);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   POST /api/auth/admin/login
// @desc    Admin login with role verification
// @access  Public
router.post('/admin/login', [
  body('email')
    .trim()
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .notEmpty()
    .withMessage('Password is required')
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { email, password } = req.body;

    console.log('🔑 Admin login attempt:', { email, hasPassword: !!password });

    // Check for user with admin or co-admin role
    const user = await User.findOne({ 
      email, 
      role: { $in: ['admin', 'co-admin'] } 
    }).select('+password');
    console.log('👤 User found:', user ? `Yes (${user.username}, ${user.role})` : 'No');
    
    if (!user) {
      console.log('❌ No admin/co-admin user found with email:', email);
      return res.status(401).json({
        success: false,
        message: 'Invalid admin credentials'
      });
    }

    // Check if user is active
    if (!user.isActive) {
      console.log('❌ User account is deactivated');
      return res.status(401).json({
        success: false,
        message: 'Account is deactivated'
      });
    }

    // Check if password matches
    console.log('🔐 Checking password...');
    const isMatch = await user.comparePassword(password);
    console.log('🔐 Password match:', isMatch);
    
    if (!isMatch) {
      console.log('❌ Password does not match');
      return res.status(401).json({
        success: false,
        message: 'Invalid admin credentials'
      });
    }

    // Update last login
    user.lastLogin = Date.now();
    await user.save();

    const token = generateToken(user._id);
    const refreshToken = generateRefreshToken(user._id);

    // Audit Log
    req.user = user;
    await logAction(req, 'ADMIN_LOGIN', 'AUTH', { 
      userId: user._id, 
      email: user.email, 
      role: user.role 
    });

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    });

    res.json({
      success: true,
      data: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        permissions: user.permissions,
        token, // Keep for backward compatibility during transition
        refreshToken
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   POST /api/auth/refresh
// @desc    Refresh access token
// @access  Public
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({
        success: false,
        message: 'Refresh token is required'
      });
    }

    // Verify refresh token
    const jwtSecret = process.env.JWT_SECRET || 'default-secret-change-in-production';
    const decoded = jwt.verify(refreshToken, jwtSecret);

    if (decoded.type !== 'refresh') {
      return res.status(401).json({
        success: false,
        message: 'Invalid refresh token'
      });
    }

    // Get user
    const user = await User.findById(decoded.id);

    if (!user || !user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'User not found or inactive'
      });
    }

    // Generate new tokens
    const newToken = generateToken(user._id);
    const newRefreshToken = generateRefreshToken(user._id);

    res.json({
      success: true,
      data: {
        token: newToken,
        refreshToken: newRefreshToken
      }
    });
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired refresh token'
    });
  }
});

// @route   POST /api/auth/anonymous
// @desc    Create anonymous session
// @access  Public
router.post('/anonymous', async (req, res) => {
  try {
    // Generate a temporary token without user
    const anonymousId = 'anonymous_' + Date.now();
    const jwtSecret = process.env.JWT_SECRET || 'default-secret-change-in-production';
    const token = jwt.sign({ id: anonymousId, anonymous: true }, jwtSecret, {
      expiresIn: '1d'
    });

    res.json({
      success: true,
      data: {
        id: anonymousId,
        anonymous: true,
        token
      }
    });
  } catch (error) {
    console.error('Anonymous session error:', error);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   GET /api/auth/me
// @desc    Get current user
// @access  Private
router.get('/me', protect, async (req, res) => {
  res.json({
    success: true,
    data: {
      id: req.user._id,
      username: req.user.username,
      email: req.user.email,
      role: req.user.role,
      permissions: req.user.permissions
    }
  });
});

// @route   PUT /api/auth/profile
// @desc    Update user profile
// @access  Private
router.put('/profile', protect, [
  body('username')
    .optional()
    .trim()
    .isLength({ min: 3, max: 30 })
    .withMessage('Username must be between 3 and 30 characters')
    .matches(/^[a-zA-Z0-9_-]+$/)
    .withMessage('Username can only contain letters, numbers, underscores and hyphens'),
  body('email')
    .optional()
    .trim()
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email')
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { username, email } = req.body;
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if new email is already taken
    if (email && email !== user.email) {
      const emailExists = await User.findOne({ email });
      if (emailExists) {
        return res.status(400).json({
          success: false,
          message: 'Email already in use'
        });
      }
      user.email = email;
    }

    // Check if new username is already taken
    if (username && username !== user.username) {
      const usernameExists = await User.findOne({ username });
      if (usernameExists) {
        return res.status(400).json({
          success: false,
          message: 'Username already in use'
        });
      }
      user.username = username;
    }

    await user.save();

    res.json({
      success: true,
      data: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        permissions: user.permissions
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   PUT /api/auth/change-password
// @desc    Change user password
// @access  Private
router.put('/change-password', protect, [
  body('currentPassword')
    .notEmpty()
    .withMessage('Current password is required'),
  body('newPassword')
    .isLength({ min: 8 })
    .withMessage('New password must be at least 8 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one uppercase letter, one lowercase letter, and one number')
], async (req, res) => {
  try {
    // Check validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { currentPassword, newPassword } = req.body;

    const user = await User.findById(req.user._id).select('+password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Verify current password
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    // Audit Log
    await logAction(req, 'CHANGE_PASSWORD', 'AUTH', { userId: user._id });

    res.json({
      success: true,
      message: 'Password changed successfully'
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   GET /api/auth/users
// @desc    Get all users (admin only)
// @access  Private/Admin
router.get('/users', protect, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    const users = await User.find().select('-password').sort({ createdAt: -1 });

    res.json({
      success: true,
      data: users
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   POST /api/auth/users
// @desc    Create a new user (admin only)
// @access  Private/Admin
router.post('/users', protect, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    const { username, email, password, role, adminType, permissions } = req.body;

    console.log('👥 Creating new user:', { username, email, role: role || 'user', adminType, permissions });

    // Validate input
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide username, email, and password'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters'
      });
    }

    // Check if user exists
    const userExists = await User.findOne({ $or: [{ email }, { username }] });
    if (userExists) {
      return res.status(400).json({
        success: false,
        message: 'User with this email or username already exists'
      });
    }

    // Create user with permissions
    const userData = {
      username,
      email,
      password,
      role: role || 'user',
      adminType: adminType || null,
      isActive: true
    };

    // Create user
    const user = new User(userData);
    
    // Set permissions using set() for reliability
    if (permissions) {
      user.set('permissions.canViewDashboard', permissions.canViewDashboard === true);
      user.set('permissions.canViewScans', permissions.canViewScans === true);
      user.set('permissions.canManageCoAdmins', permissions.canManageCoAdmins === true);
      user.set('permissions.canDelete', permissions.canDelete === true);
      user.set('permissions.canExport', permissions.canExport === true);
      user.set('permissions.canManageUsers', permissions.canManageUsers === true);
      user.set('permissions.canViewRewards', permissions.canViewRewards === true);
      user.set('permissions.canViewLeaderboard', permissions.canViewLeaderboard === true);
      user.set('permissions.canManageProducts', permissions.canManageProducts === true);
      user.set('permissions.canManageQRCodes', permissions.canManageQRCodes === true);
      user.set('permissions.canManageCoAdminRequests', permissions.canManageCoAdminRequests === true);
      user.set('permissions.canManageApplicators', permissions.canManageApplicators === true);
      user.set('permissions.canPrintQRCodes', permissions.canPrintQRCodes === true);
      user.set('permissions.canViewQRAnalytics', permissions.canViewQRAnalytics === true);
    }

    // For QR admin type, automatically enable QR permissions
    if (adminType === 'qr_admin') {
      user.set('permissions.canViewDashboard', true);
      user.set('permissions.canDelete', false);
      user.set('permissions.canExport', false);
      user.set('permissions.canManageUsers', false);
      user.set('permissions.canManageProducts', false);
      user.set('permissions.canManageQRCodes', true);
      user.set('permissions.canManageApplicators', false);
      user.set('permissions.canPrintQRCodes', true);
      user.set('permissions.canViewQRAnalytics', true);
    }

    await user.save();

    console.log('✅ User created successfully:', user.username);

    // Audit Log
    await logAction(req, 'CREATE_USER', 'USERS', { 
      createdUserId: user._id, 
      email: user.email, 
      role: user.role 
    });

    res.status(201).json({
      success: true,
      data: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        adminType: user.adminType,
        isActive: user.isActive,
        permissions: user.permissions
      },
      message: 'User created successfully'
    });
  } catch (error) {
    console.error('❌ User creation error:', error);
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   PUT /api/auth/users/:id
// @desc    Update user (admin only)
// @access  Private/Admin
router.put('/users/:id', protect, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    const { role, isActive, points, permissions, username, email } = req.body;
    console.log('📝 Updating user:', req.params.id, { permissions });
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Use an atomic $set update to ensure nested permissions are persisted regardless of Mongoose instance tracking
    const updateData = {
      $set: {
        ...(username !== undefined && { username }),
        ...(email !== undefined && { email }),
        ...(role !== undefined && { role }),
        ...(isActive !== undefined && { isActive }),
        ...(points !== undefined && { points: Math.max(0, points) }),
        ...(permissions !== undefined && {
          'permissions.canViewDashboard': permissions.canViewDashboard === true,
          'permissions.canViewScans': permissions.canViewScans === true,
          'permissions.canManageCoAdmins': permissions.canManageCoAdmins === true,
          'permissions.canDelete': permissions.canDelete === true,
          'permissions.canExport': permissions.canExport === true,
          'permissions.canManageUsers': permissions.canManageUsers === true,
          'permissions.canViewRewards': permissions.canViewRewards === true,
          'permissions.canViewLeaderboard': permissions.canViewLeaderboard === true,
          'permissions.canManageProducts': permissions.canManageProducts === true,
          'permissions.canManageQRCodes': permissions.canManageQRCodes === true,
          'permissions.canManageCoAdminRequests': permissions.canManageCoAdminRequests === true,
          'permissions.canManageApplicators': permissions.canManageApplicators === true
        })
      }
    };

    await User.updateOne({ _id: req.params.id }, updateData, { runValidators: true });
    
    // Fetch the updated document to confirm and return
    const updatedUser = await User.findById(req.params.id);

    if (points !== undefined) {
      updatedUser.updateTier();
      await updatedUser.save();
    }

    res.json({
      success: true,
      data: {
        _id: updatedUser._id,
        username: updatedUser.username,
        email: updatedUser.email,
        role: updatedUser.role,
        isActive: updatedUser.isActive,
        points: updatedUser.points,
        tier: updatedUser.tier,
        permissions: updatedUser.permissions
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   PUT /api/auth/users/:id/reset-password
// @desc    Reset user password (main admin only)
// @access  Private/Main Admin
router.put('/users/:id/reset-password', protect, async (req, res) => {
  try {
    // Only main admin can reset other users' passwords
    if (req.user.role !== 'admin' || req.user.email !== 'admin@megakem.com') {
      return res.status(403).json({
        success: false,
        message: 'Only the main admin can reset user passwords'
      });
    }

    const { newPassword } = req.body;

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters'
      });
    }

    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update password
    user.password = newPassword;
    await user.save();

    res.json({
      success: true,
      message: 'Password reset successfully'
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   PUT /api/auth/users/:id/points
// @desc    Update user loyalty points (admin only)
// @access  Private/Admin
router.put('/users/:id/points', protect, [
  body('points')
    .isInt({ min: 0 })
    .withMessage('Points must be a non-negative integer'),
  body('operation')
    .optional()
    .isIn(['set', 'add', 'subtract'])
    .withMessage('Operation must be set, add, or subtract')
], async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: errors.array()
      });
    }

    const { points, operation = 'set' } = req.body;
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Update points based on operation
    if (operation === 'set') {
      user.points = Math.max(0, points);
    } else if (operation === 'add') {
      user.points = Math.max(0, user.points + points);
    } else if (operation === 'subtract') {
      user.points = Math.max(0, user.points - points);
    }

    // Update tier based on new points
    user.updateTier();
    await user.save();

    res.json({
      success: true,
      data: {
        id: user._id,
        username: user.username,
        email: user.email,
        points: user.points,
        tier: user.tier
      },
      message: `Points ${operation === 'set' ? 'set' : operation === 'add' ? 'added' : 'subtracted'} successfully`
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   DELETE /api/auth/users/:id
// @desc    Delete user (admin only)
// @access  Private/Admin
router.delete('/users/:id', protect, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    // Prevent admin from deleting themselves
    if (user._id.toString() === req.user._id.toString()) {
      return res.status(400).json({
        success: false,
        message: 'You cannot delete your own account'
      });
    }

    await User.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   GET /api/auth/stats
// @desc    Get dashboard statistics (admin only)
// @access  Private/Admin
router.get('/stats', protect, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Access denied'
      });
    }

    const totalUsers = await User.countDocuments();
    const activeUsers = await User.countDocuments({ isActive: true });
    const adminUsers = await User.countDocuments({ role: 'admin' });

    res.json({
      success: true,
      data: {
        totalUsers,
        activeUsers,
        adminUsers
      }
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message
    });
  }
});

// @route   GET /api/auth/me
// @desc    Get current user session
// @access  Private
router.get('/me', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    
    res.json({
      success: true,
      data: {
        id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        permissions: user.permissions,
        points: user.points,
        tier: user.tier
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server Error' });
  }
});

module.exports = router;
