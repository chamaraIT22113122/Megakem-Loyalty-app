const mongoose = require('mongoose');
const dotenv = require('dotenv');
const dns = require('dns');

// DNS fix
dns.setDefaultResultOrder('ipv4first');
dns.setServers(['8.8.8.8', '8.8.4.4', '1.1.1.1']);

const uri = "mongodb+srv://megakemit_db_user:Megakemloyalty2026@megakemloyalty.gf75mvv.mongodb.net/megakem-loyalty?retryWrites=true&w=majority";
console.log('Testing connection to new DB...');

mongoose.connect(uri, {
  serverSelectionTimeoutMS: 5000
})
.then(conn => {
  console.log('✅ Connection Successful!');
  console.log('Host:', conn.connection.host);
  process.exit(0);
})
.catch(err => {
  console.error('❌ Connection Failed!');
  console.error(err.message);
  process.exit(1);
});
