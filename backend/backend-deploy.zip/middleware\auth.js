const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Protect routes - verify JWT token
exports.protect = async (req, res, next) => {
  let token;

  // Check for token in Authorization header or cookies
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  // Make sure token exists
  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Not authorized to access this route'
    });
  }

  try {
    // Verify token
    const jwtSecret = process.env.JWT_SECRET || 'default-secret-change-in-production';
    const decoded = jwt.verify(token, jwtSecret);

    // Check token expiration explicitly
    if (decoded.exp && Date.now() >= decoded.exp * 1000) {
      return res.status(401).json({
        success: false,
        message: 'Token has expired. Please login again.',
        expired: true
      });
    }

    // Check if it's an anonymous token
    if (decoded.anonymous) {
      req.user = { id: decoded.id, anonymous: true };
      return next();
    }

    // Get user from token
    req.user = await User.findById(decoded.id);

    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'User not found'
      });
    }

    // Check if user is active
    if (req.user.isActive === false) {
      return res.status(401).json({
        success: false,
        message: 'Account has been deactivated'
      });
    }

    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Token has expired. Please login again.',
        expired: true
      });
    }
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: 'Invalid token'
      });
    }
    return res.status(401).json({
      success: false,
      message: 'Not authorized to access this route'
    });
  }
};

// Grant access to specific roles
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: `User role '${req.user.role}' is not authorized to access this route`
      });
    }
    next();
  };
};

// Admin only middleware
exports.admin = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Access denied. Admin privileges required.'
    });
  }
  next();
};

// Optional authentication - doesn't fail if no token
exports.optionalAuth = async (req, res, next) => {
  let token;

  // Check for token in Authorization header
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  // If no token, just continue without user
  if (!token) {
    return next();
  }

  try {
    // Verify token
    const jwtSecret = process.env.JWT_SECRET || 'default-secret-change-in-production';
    const decoded = jwt.verify(token, jwtSecret);

    // Check if it's an anonymous token
    if (decoded.anonymous) {
      req.user = { id: decoded.id, anonymous: true };
      return next();
    }

    // Get user from token
    req.user = await User.findById(decoded.id);
    next();
  } catch (error) {
    // Token is invalid, but we don't fail - just continue without user
    next();
  }
};

// QR Code Admin - can manage QR codes
exports.qrAdmin = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: 'Not authenticated'
    });
  }

  // Allow super admin, QR admin, or anyone with manage/print QR code permissions or reprint request permissions
  if (
    req.user.role === 'admin' || 
    req.user.adminType === 'qr_admin' || 
    req.user.permissions?.canManageQRCodes || 
    req.user.permissions?.canPrintQRCodes || 
    req.user.permissions?.canManageCoAdminRequests
  ) {
    return next();
  }

  return res.status(403).json({
    success: false,
    message: 'Access denied. QR code admin privileges required.'
  });
};

// Check specific permissions
exports.hasPermission = (permission) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Not authenticated'
      });
    }

    // Super admin has all permissions
    if (req.user.role === 'admin') {
      return next();
    }

    // Auto-grant scans database access to all admins and co-admins
    if (permission === 'canViewScans' && (req.user.role === 'admin' || req.user.role === 'co-admin')) {
      return next();
    }

    if (req.user.permissions && req.user.permissions[permission]) {
      return next();
    }

    return res.status(403).json({
      success: false,
      message: `Access denied. Missing permission: ${permission}`
    });
  };
};
